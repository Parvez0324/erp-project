<?php

return [
    'name' => 'Contact'
];
