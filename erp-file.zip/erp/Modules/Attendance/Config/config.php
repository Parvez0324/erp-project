<?php

return [
    'name' => 'Attendance'
];
